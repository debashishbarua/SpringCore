package com.cts.springdi.setter;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

	@Bean
	public Student getStudentBean() {
		Student student = new Student();
		student.setId(101);
		student.setName("Name");
		student.setMarks(89.21);
		return student;
	}

}
