package com.cts.springdi.constructor;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PersonApp {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("personConfiguration.xml");
		Person person = ctx.getBean(Person.class, "person");
		System.out.println(person);
		
	}

}
