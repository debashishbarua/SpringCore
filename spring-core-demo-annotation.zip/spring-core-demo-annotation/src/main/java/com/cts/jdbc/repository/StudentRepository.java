package com.cts.jdbc.repository;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cts.jdbc.model.Student;

@Repository
public class StudentRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public StudentRepository() {

	}

	public void setJdbcTemplate(DataSource dataSource) {

		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public List<Student> findAll() {
		String sql = "select * from Student";
		return jdbcTemplate.query(sql, new StudentMapper());
	}

	public void save(Student student) {
		String sql = "insert into student values(?,?)";
		jdbcTemplate.update(sql, student.getId(), student.getName());

	}

}
