package com.cts.jdbc;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cts.jdbc.config.AppConfig;
import com.cts.jdbc.model.Student;
import com.cts.jdbc.service.StudentService;

public class JdbcApp {
	
	public static void main(String[] args) {

		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);

		StudentService service = ctx.getBean(StudentService.class);

		Student student = new Student(13, "Akash");

		//service.save(student);
		System.out.println(service.findAll());
	}
}
