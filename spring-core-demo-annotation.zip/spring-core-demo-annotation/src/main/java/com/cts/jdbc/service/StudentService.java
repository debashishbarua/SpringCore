package com.cts.jdbc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.jdbc.model.Student;
import com.cts.jdbc.repository.StudentRepository;

@Service
public class StudentService {
	
	@Autowired
	private StudentRepository studentRepository;

	public StudentService() {

	}

	public void setStudentRepository(StudentRepository studentRepository) {
		this.studentRepository = studentRepository;
	}

	public List<Student> findAll() {
		return studentRepository.findAll();
	}

	public void save(Student student) {
		studentRepository.save(student);

	}
}
