package com.cts.aop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AOPApp {
	public static void main(String[] args) {
	      ApplicationContext context = new ClassPathXmlApplicationContext("aopconfig.xml");
	      
	      AppAPI app = context.getBean(AppAPI.class);
	      
	      app.display();
	      System.out.println(app.getMsg());
	      
	     
	   }
}
