package com.cts.aop;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class MyAspect {

	// @Pointcut("execution(* com.tutorialspoint.*.*(..))")
	@Pointcut("execution(public void com.cts.aop.AppAPI.display())")
	private void displayPointCut() {
	}
	
	@Pointcut("execution(public String com.cts.aop.AppAPI.getMsg())")
	private void getPointCut() {
	}

	@Before("displayPointCut()")
	public void beforeAdvice() {
		System.out.println("Going to setup student profile.");
	}

	@After("displayPointCut()")
	public void afterAdvice() {
		System.out.println("Student profile has been setup.");
	}
	@Before("getPointCut()")
	public void beforeAdviceGetMsg() {
		System.out.println("Before geting msg.");
	}
}
