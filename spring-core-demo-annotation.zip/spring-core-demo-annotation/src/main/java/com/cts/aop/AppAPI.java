package com.cts.aop;

public class AppAPI {

	private String msg;
	
	public AppAPI() {
		
	}
	
	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public void display() {
		System.out.println("My App Displaying");
	}

}
