package com.cts.autowiring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

	@Bean
	public Address getAddress() {
		return new Address("Kolkata", "India");
	}
	
	@Bean
	public Person getPerson() {
		Person p=new Person();
		p.setName("Name");
		p.setId(123);
		return p;
	}
}
