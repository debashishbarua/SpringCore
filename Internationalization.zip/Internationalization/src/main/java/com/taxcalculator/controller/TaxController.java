package com.taxcalculator.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.taxcalculator.model.UserClaim;

@Controller
public class TaxController {

	@ModelAttribute("expenseList")
	public List<String> populateExpense() {
		List<String> expenseTypeList = new ArrayList<String>();
		expenseTypeList.add("Medical Expense");
		expenseTypeList.add("Travel Expense");
		expenseTypeList.add("Food Expense");
		return expenseTypeList;
	}
	
	@RequestMapping(value="/getTaxClaimFormPage", method = RequestMethod.GET)
	public String claimPage(@ModelAttribute("userClaim") UserClaim userClaim) {
		return "taxclaim";
	}

}

