package com.taxcalculator.model;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PositiveOrZero;


public class UserClaim {

	@NotNull(message = "{employeeId.notEmpty}")
	@Digits(integer = 5, fraction = 0, message = "{employeeId.Length}")
	private int employeeId;
	
	private String expenseType;
	
	@PositiveOrZero(message = "{expenseAmount.Negative}")
	private double expenseAmt;

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getExpenseType() {
		return expenseType;
	}

	public void setExpenseType(String expenseType) {
		this.expenseType = expenseType;
	}

	public double getExpenseAmt() {
		return expenseAmt;
	}

	public void setExpenseAmt(double expenseAmt) {
		this.expenseAmt = expenseAmt;
	}

}

