package com.cts.jdbc.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cts.jdbc.confing.AppConfig;
import com.cts.jdbc.repository.StudentRepository;

public class Main {

	public static void main(String[] args) {

		//ApplicationContext ctx = new ClassPathXmlApplicationContext("bean.xml");
		ApplicationContext ctx=new AnnotationConfigApplicationContext(AppConfig.class);		
		StudentRepository repository=ctx.getBean(StudentRepository.class);
		//System.out.println(repository);
		
		System.out.println(repository.findAll());

	}

}
