package com.cts.mockito.student.dao;

import java.util.List;

import com.cts.mockito.student.model.Student;

public interface StudentDao {

	public String create(Student student);
	public List<Student> findAll();

}
