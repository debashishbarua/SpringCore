package com.cts.mockito.student.main;

import java.text.DecimalFormat;

public class StudentApp {

	public static void main(String[] args) {
//		double d = 2343.5476;
//		DecimalFormat df = new DecimalFormat("###.##");
//		String dd = df.format(d);
		
		double d=2343.5476;
        double roundedDouble = Math.round(d * 100.0) / 100.0;
        System.out.println("Rounded double: "+roundedDouble);
 
//        float f=2343.5476f;
//        float roundedFloat = (float)Math.round(f * 100.0) / 100.0;
//        System.out.println("Rounded float: "+roundedFloat);
	}

}
