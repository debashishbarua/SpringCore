package com.cts.mockito.student.service;

import java.util.List;

import com.cts.mockito.student.dao.StudentDao;
import com.cts.mockito.student.model.Student;

public class StudentService {

	private StudentDao dao;
	
	public StudentService(StudentDao dao) {
		this.dao = dao;
	}

	public String create(Student student) {
		return dao.create(student);
	}

	public List<Student> findAll() {
		return dao.findAll();
	}
}
