package com.cts.testing;

public class Calculator {
	public int multiply(int a, int b) {
		return a * b;
	}
}
