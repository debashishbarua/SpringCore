package com.cts.mockito.student.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cts.mockito.student.dao.StudentDao;
import com.cts.mockito.student.model.Student;

class StudentServiceTest {

	StudentService service;

	@Mock
	StudentDao dao;

	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testCreate() {
		
		Student student = new Student();
		
		service = new StudentService(dao);
		
		String expected = "SUCCESS";
		
		when(dao.create(student)).thenReturn("SUCCESS");
		
		String actual = service.create(student);
		
		assertEquals(expected, actual);

	}

	@Test
	void testFindAll() {		
		service = new StudentService(dao);
		
		List<Student> expected = new ArrayList<>();
		
		when(dao.findAll()).thenReturn(expected);
		
		List<Student> actual = service.findAll();
		
		assertEquals(expected, actual);

	}

}
