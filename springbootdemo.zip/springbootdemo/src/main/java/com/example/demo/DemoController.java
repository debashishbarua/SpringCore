package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DemoController {
	
	@RequestMapping(value = "loginPage" ,  method = RequestMethod.GET)
	public String getLoginPage() {
		System.out.println("Get Login Page ");
		return "loginPage";
	}
	
	@RequestMapping(value = "login", method = RequestMethod.POST)
	public String loginCheck(
			@RequestParam("userName") String userName,
			@RequestParam("password") String password) {
		
		User user=new User();
		user.setUserName(userName);
		user.setPassword(password);
		System.out.println(user);
		//Check
		if(user.isValid()) {
			return "success";
		}else {
			return "fail";
		}
	}

}
