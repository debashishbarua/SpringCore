package com.example.demo.jdbc.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.demo.jdbc.model.Developer;

@Repository
public class DeveloperDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public Developer getDeveloper(final int id) {
		return jdbcTemplate.queryForObject(
				"select * from Developer where id = ?",
				(rs, row) -> new Developer(rs.getInt("id"), 
						rs.getString("name"), 
						rs.getString("expertise")),
				id);
	}

	public List<Developer> getDevelopers() {
		return jdbcTemplate.query(
				"select * from Developer",
				(rs, row) -> new Developer(rs.getInt("id"), 
						rs.getString("name"), 
						rs.getString("expertise")));
	}

	public int addDeveloper(final Developer developer) {
		return jdbcTemplate.update(
				"insert into Developer(name, expertise) values(?, ?)",
				new Object[] { developer.getName(), developer.getExpertise() });
	}

	public int updateDeveloper(final Developer developer) {
		return jdbcTemplate.update("update Developer set name = ?, expertise = ? where id = ?",
				new Object[] { developer.getName(), developer.getExpertise(), developer.getId() });
	}

	public int deleteDeveloper(final int id) {
		return jdbcTemplate.update("delete from Developer where id = ?", new Object[] { id });
	}
}
