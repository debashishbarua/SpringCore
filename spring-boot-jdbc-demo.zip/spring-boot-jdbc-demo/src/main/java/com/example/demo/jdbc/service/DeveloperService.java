package com.example.demo.jdbc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.jdbc.dao.DeveloperDao;
import com.example.demo.jdbc.model.Developer;

@Service
public class DeveloperService {
	
	@Autowired
	private DeveloperDao developerDao;

	public Developer getDeveloper(final int id) {
		return developerDao.getDeveloper(id);
	}

	public List<Developer> getDevelopers() {
		return developerDao.getDevelopers();
	}

	public int addDeveloper(final Developer developer) {
		return developerDao.addDeveloper(developer);
	}

	public int updateDeveloper(final Developer developer) {
		return developerDao.updateDeveloper(developer);
	}

	public int deleteDeveloper(final int id) {
		return developerDao.deleteDeveloper(id);
	}

}
