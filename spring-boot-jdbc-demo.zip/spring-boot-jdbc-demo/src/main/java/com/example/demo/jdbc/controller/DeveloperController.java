package com.example.demo.jdbc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.jdbc.model.Developer;
import com.example.demo.jdbc.service.DeveloperService;

@Controller
public class DeveloperController {

	@Autowired
	private DeveloperService developerService;
	//http://localhost:8181//developer/10 -> Path variable
	//http://localhost:8181//developer?id=10 -Request Param
	@GetMapping("/developer/{id}")
	public String getDeveloper(
			@PathVariable("id") int id, 
			ModelMap developerModel) {
		
		Developer developer = developerService.getDeveloper(id);
		
		developerModel.addAttribute("developer", developer);
		return "developer";
	}

	@GetMapping("/developers")
	public String getDevelopers(ModelMap developerModel) {
		
		List<Developer> developers = developerService.getDevelopers();
		developerModel.addAttribute("developers", developers);
		
		return "developers";
	}

	@GetMapping("addDeveloper")
	public String addPage() {
		return "add";
	}

	@PostMapping("/add/developer")
	public String addDeveloper(
			@RequestParam(value = "name", required = true) String name,
			@RequestParam(value = "expertise", required = true) String expertise, 
			ModelMap developerModel) {
		Developer developer = new Developer();
		developer.setName(name);
		developer.setExpertise(expertise);
		developerService.addDeveloper(developer);
		developerModel.addAttribute("msg", "Developer added successfully");
		List<Developer> developers = developerService.getDevelopers();
		developerModel.addAttribute("developers", developers);
		return "redirect:/developers";
	}

	@GetMapping("update/developer/{id}")
	public String updatePage(@PathVariable("id") int id, ModelMap developerModel) {
		developerModel.addAttribute("id", id);
		Developer developer = developerService.getDeveloper(id);
		developerModel.addAttribute("developer", developer);
		return "update";
	}

	@PostMapping("/update/developer")
	public String updateDeveloper(
			@RequestParam int id, 
			@RequestParam(value = "name", required = true) String name,
			@RequestParam(value = "expertise", required = true) String expertise, 
			ModelMap developerModel) {
		Developer developer = new Developer(id, name, expertise);

		developerService.updateDeveloper(developer);
		List<Developer> developers = developerService.getDevelopers();
		developerModel.addAttribute("developers", developers);
		developerModel.addAttribute("id", id);
		developerModel.addAttribute("msg", "Developer updated successfully");
		return "redirect:/developers";
	}

	@GetMapping("/delete/developer/{id}")
	public String deleteDeveloper(@PathVariable int id, ModelMap developerModel) {
		developerService.deleteDeveloper(id);
		List<Developer> developers = developerService.getDevelopers();
		developerModel.addAttribute("developers", developers);
		developerModel.addAttribute("msg", "Developer delted successfully");
		return "redirect:/developers";
	}

}
