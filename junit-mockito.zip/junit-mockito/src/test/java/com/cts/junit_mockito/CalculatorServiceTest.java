package com.cts.junit_mockito;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.timeout;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;


class CalculatorServiceTest {

	@Test
	void testAdd() {
		AddService addService;
		CalculatorService calculatorService;
		
		//Creating the mock Object
		addService = Mockito.mock(AddService.class);
		//Inject the mock 
		calculatorService = new CalculatorService(addService);
	
		int num1 =10;
		int num2=20;
		int expected=30;
		
		when(addService.add(num1, num2)).thenReturn(30);
		
		int actual=calculatorService.add(num1, num2);
		
		assertEquals(expected, actual);
		
		verify(addService).add(num1, num2);
		verify(addService,times(5)).add(num1, num2);
		
	}

}
