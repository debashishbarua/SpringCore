package com.cts.junit_mockito;

public class CalculatorService {
	
	private AddService addService;

	public CalculatorService(AddService addService) {		
		this.addService = addService;
	}
	
	public int add(int a,int b) {
		return addService.add(a, b);
	}
}
