package com.example.demo.controller;

import java.util.Map;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.model.User;

@Controller
public class UserController {

	@RequestMapping(value = "/registration", method = RequestMethod.GET)
	public String viewRegistration(Model model) {
		model.addAttribute("user", new User());
		return "registrationForm";
	}

	@RequestMapping(value = "/registration", method = RequestMethod.POST)
	public String doRegistration(@Valid
								@ModelAttribute("user") User user, 
								BindingResult result, 
								Model model) {
		//System.out.println("Registration Process");
		if (result.hasErrors()) {
			return "registrationForm";
		}
		// Invoke Your Business Logic/Model logic
		return "registrationSuccess";
	}
}
