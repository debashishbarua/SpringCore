package com.example.demo.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

public class User {

	@NotEmpty(message = "{firstName.empty}")
	@Size(min = 3, max = 45, message="{firstName.size}")	
	//@NotEmpty(message = "First Name Should Not be empty")
	private String firstName;
	
	//@NotEmpty(message = "Last Name Required")
	@Size(min = 3, max = 45, message="{lastName.size}")
	@NotEmpty(message = "{lastName.empty}")
	private String lastName;

	@Email(message="{email.msg}")
	@NotBlank
	@Size(max = 150)
	//@NotEmpty(message = "Email Should Not be empty")
	private String email;
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	
//	@Pattern(regexp = "[a-zA-Z]")
//	private String regex;
//
//	@FutureOrPresent
//	@DateTimeFormat(pattern = "yyyy-MM-dd")
//	private LocalDate localDate;
//
//	@PastOrPresent
//	@DateTimeFormat(pattern = "yyyy-MM-dd")
//	private LocalDate pastDate;
//
//	@Future
//	@DateTimeFormat(pattern = "yyyy-MM-dd")
//	private LocalDate futureDate;
//
//	@Negative
//	private int negative;
//
//	@NegativeOrZero
//	private int negativeOrZero;
//

}