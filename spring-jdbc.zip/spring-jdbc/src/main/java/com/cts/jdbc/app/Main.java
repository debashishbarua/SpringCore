package com.cts.jdbc.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.jdbc.repository.StudentRepository;

public class Main {

	public static void main(String[] args) {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("bean.xml");

		
		StudentRepository repository=ctx.getBean(StudentRepository.class);
		//System.out.println(repository);
		
		System.out.println(repository.findAll());

	}

}
