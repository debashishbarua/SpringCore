package com.cts.jdbc.repository;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.cts.jdbc.model.Student;

public class StudentRepository {

	private JdbcTemplate jdbcTemplate;

	public StudentRepository() {

	}

	public void setJdbcTemplate(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	
	public List<Student> findAll(){		
		String sql="select * from student";
		return jdbcTemplate.query(sql, new StudentMapper());
		
	}
	
	public void create(Student student) {
		
	}
}
