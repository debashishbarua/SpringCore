package com.cognizant.employees;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.employees.model.Employee;
import com.cognizant.employees.services.EmployeeService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootApplication
public class EmployeesApplication {

	private static EmployeeService employeeService;

	public static void main(String[] args) {

		ApplicationContext context = SpringApplication.run(EmployeesApplication.class, args);
		log.info("Start");
		employeeService = context.getBean(EmployeeService.class);
		testSaveEmployee();
		log.info("End");
	}

	public static void testSaveEmployee() {
		log.info("Start");
		Employee employee=new Employee("Akash", "Kumar");
		Employee saveEmployee=employeeService.save(employee);
		log.debug("Saved Employee : {} " , saveEmployee);
	}
}
