/**
 * 
 */
package com.cts.unit_testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * @author 91967
 *
 */
class CalculatorTest {

	private Calculator calculator;
	private int num1;
	private int num2;
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		calculator =new Calculator();
		num1=10;
		num2=20;
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterEach
	void tearDown() throws Exception {
		calculator = null;
	}

	/**
	 * Test method for {@link com.cts.unit_testing.Calculator#add(int, int)}.
	 */
	@Test
	void testAdd() {
		assertEquals(30, calculator.add(num1, num2));
	}

	/**
	 * Test method for {@link com.cts.unit_testing.Calculator#mul(int, int)}.
	 */
	@Test
	void testMul() {
		assertEquals(200, calculator.mul(num1, num2));
	}

}
