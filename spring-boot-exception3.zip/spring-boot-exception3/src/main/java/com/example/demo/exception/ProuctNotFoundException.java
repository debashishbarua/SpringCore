package com.example.demo.exception;

public class ProuctNotFoundException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ProuctNotFoundException() {
		super();

	}

	public ProuctNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public ProuctNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public ProuctNotFoundException(String message) {
		super(message);
	}

	public ProuctNotFoundException(Throwable cause) {
		super(cause);
	}

}
