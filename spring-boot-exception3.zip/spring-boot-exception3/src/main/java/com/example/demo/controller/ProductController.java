package com.example.demo.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.exception.ProuctNotFoundException;
import com.example.demo.model.Product;
import com.example.demo.repository.ProductRepository;

@Controller
public class ProductController {

	@Autowired
	private ProductRepository productRepository;

	@RequestMapping(value = "/products/{id}", method = RequestMethod.GET)
	public String showOrder(@PathVariable("id") long id, Model model) {
		Product product = productRepository.findById(id);
		if (product == null)
			throw new ProuctNotFoundException(id + "");
		model.addAttribute(product);
		return "productDetail";
	}

	
}
