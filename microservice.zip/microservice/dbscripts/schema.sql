 use docker_db;

CREATE TABLE countries (

 country varchar(255) NOT NULL,

 capital varchar(255) NOT NULL,

 currency varchar(255) NOT NULL,

 currencysimbol varchar(255) NOT NULL,

 language varchar(255) NOT NULL,

 name varchar(255) NOT NULL,

 PRIMARY KEY (country)

);