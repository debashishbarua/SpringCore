package com.cognizant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.model.Employee;
import com.cognizant.repository.EmployeeRepository;
import com.cognizant.repository.EmployeeRepositoryCustomImpl;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository repository;

	@Autowired
	private EmployeeRepositoryCustomImpl employeeRepositoryCustomImpl;

	@Transactional
	public List<Employee> getAllEmps(String firstName, String lastName) {
		return employeeRepositoryCustomImpl.getAllEmps(firstName, lastName);
	}

	@Transactional
	public List<Employee> getAllEmps() {
		return employeeRepositoryCustomImpl.getAllEmps();
	}

	@Transactional
	public void save(Employee employee) {
		repository.save(employee);
	}

	@Transactional
	public List<Employee> findAll() {
		return repository.findAll();
	}

	@Transactional
	public Employee findByFirstName(String firstName) {
		return repository.findByFirstName(firstName);
	}

	@Transactional
	public Employee findByFirstNameAndLastName(String firstName, String lastName) {
		return repository.findByFirstNameAndLastName(firstName, lastName);
	}

	public List<Employee> getAllPermanentEmployees() {
		return repository.getAllEmployees();
	}

	public List<Employee> getAllEmployeesNative() {
		return repository.getAllEmployeesNative();
	}
}
