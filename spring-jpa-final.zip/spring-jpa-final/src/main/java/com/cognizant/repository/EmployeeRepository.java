package com.cognizant.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

	/*
	 * Query Method
	 */
	public Employee findByFirstName(String firstName);

	public Employee findByFirstNameAndLastName(String firstName, String lastName);

	/*
	 * Using HQL
	 */
	@Query(value = "SELECT e FROM Employee e")
	public List<Employee> getAllEmployees();

	/*
	 * Native Query
	 */
	@Query(value = "SELECT * FROM employee", nativeQuery = true)
	List<Employee> getAllEmployeesNative();

}
