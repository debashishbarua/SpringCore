package com.cognizant.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.cognizant.model.Employee;

@Repository
public class EmployeeRepositoryCustomImpl implements EmployeeRepositoryCustom {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Employee> getAllEmps() {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Employee> cq = cb.createQuery(Employee.class);
		
		Root<Employee> employee = cq.from(Employee.class);
		
		TypedQuery<Employee> query = entityManager.createQuery(cq);
		return query.getResultList();
	}

	@Override
	public List<Employee> getAllEmps(String firstName,String lastName) {
		
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Employee> cq = cb.createQuery(Employee.class);

		Root<Employee> employee = cq.from(Employee.class);
		
		Predicate firstNamePredicate = cb.equal(employee.get("firstName"), firstName);
		Predicate lastNamePredicate = cb.like(employee.get("lastName"), "%" + lastName + "%");
		
		cq.where(firstNamePredicate,lastNamePredicate);
		
		TypedQuery<Employee> query = entityManager.createQuery(cq);
		return query.getResultList();
	}

}
