package com.cognizant.repository;

import java.util.List;

import com.cognizant.model.Employee;

public interface EmployeeRepositoryCustom {

	public List<Employee> getAllEmps();
}
