package com.cognizant;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.model.Employee;
import com.cognizant.service.EmployeeService;

@SpringBootApplication
public class SpringJpaH2Application {

	private static final Logger LOGGER = LoggerFactory.getLogger(SpringJpaH2Application.class);

	private static EmployeeService service;

	public static void main(String[] args) {
		LOGGER.info("Start");
		ApplicationContext context = SpringApplication.run(SpringJpaH2Application.class, args);
		service = context.getBean(EmployeeService.class);
		testSave();
		testFindAll();
		testfindByFirstName();
		testfindByFirstNameAndLastName();
		testGetAllPermanentEmployees();
		testGetAllEmployeesNative();
		LOGGER.info("Start");
	}

	private static void testSave() {
		service.save(new Employee(101L, "Mr. X", "last"));
		service.save(new Employee(102L, "Mr. Y", "SecondLast"));
	}

	private static void testFindAll() {
		LOGGER.info("Start");
		List<Employee> employees = service.findAll();
		LOGGER.debug("countries={}", employees);

		LOGGER.info("End");

	}

	private static void testfindByFirstName() {
		LOGGER.info("Start");
		Employee employee = service.findByFirstName("Mr. Y");
		LOGGER.debug("countrie={}", employee);

		LOGGER.info("End");

	}

	private static void testfindByFirstNameAndLastName() {
		LOGGER.info("Start");
		Employee employee = service.findByFirstNameAndLastName("Mr. X", "last");
		LOGGER.debug("countrie={}", employee);
		LOGGER.info("End");

	}

	public static void testGetAllPermanentEmployees() {
		LOGGER.info("Start");
		List<Employee> employees = service.getAllPermanentEmployees();
		LOGGER.debug("Permanent Employees:{}", employees);
		employees.forEach(e -> LOGGER.debug("firstName:{}", e.getFirstName()));
		LOGGER.info("End");
	}
	
	public static void testGetAllEmployeesNative() {
		LOGGER.info("Start");
		List<Employee> employees = service.getAllEmployeesNative();
		LOGGER.debug("Permanent Employees:{}", employees);
		employees.forEach(e -> LOGGER.debug("firstName:{}", e.getFirstName()));
		LOGGER.info("End");
	}
}
