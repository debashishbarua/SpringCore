package com.cts.springdi.constructor;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MultiPersonApp {

	public static void main(String[] args) {
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("multiPersonConfiguration.xml");
		Person personOne = (Person) ctx.getBean( "personOne");
		System.out.println(personOne);
		Person personTwo = (Person) ctx.getBean( "personTwo");
		System.out.println(personTwo);
	}

}
