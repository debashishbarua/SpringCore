package com.cts.springdi.constructor;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ConstructorApp {

	public static void main(String[] args) {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("employeeConfiguration.xml");
		//Employee employee = ctx.getBean(Employee.class, "employee");
		//Employee employee = ctx.getBean(Employee.class);
		Employee employee = (Employee) ctx.getBean("employee");

		System.out.println(employee);
		
		
	}

}
