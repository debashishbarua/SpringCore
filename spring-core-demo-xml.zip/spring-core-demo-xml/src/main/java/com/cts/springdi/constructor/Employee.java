package com.cts.springdi.constructor;


public class Employee {
	private int id;
	private String name;
	private Department department;



	public Employee() {
		
	}

	public Employee(int id, String name, Department department) {
		super();
		this.id = id;
		this.name = name;
		this.department = department;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", department=" + department + "]";
	}

	

}
