package com.cts.springdi.setter;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class SetterApp {

	public static void main(String[] args) {

		ApplicationContext ctx = new FileSystemXmlApplicationContext("classpath:configuration.xml");
		Student student = ctx.getBean(Student.class, "student");
		System.out.println(student);
		
		
	}

}
