package com.cts.interfacedi;

public class BasicCalculator implements Operation {

	@Override
	public int add(int a, int b) {

		return a + b;
	}
	
}
