package com.cts.interfacedi;

public interface Operation {
	int add(int a, int b);
}
