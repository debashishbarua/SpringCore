package com.cts.inheritance;

public class Child extends Base {
	private String child;

	public Child() {
		// TODO Auto-generated constructor stub
	}

	public String getChild() {
		return child;
	}

	public void setChild(String child) {
		this.child = child;
	}

	@Override
	public String toString() {
		return super.toString() +"Child [child=" + child + "]";
	}

}
