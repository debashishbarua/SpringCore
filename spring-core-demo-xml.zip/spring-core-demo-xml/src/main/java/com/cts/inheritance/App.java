package com.cts.inheritance;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("inheritance.xml");

		Child c=ctx.getBean(Child.class);
		System.out.println(c);

	}

}
