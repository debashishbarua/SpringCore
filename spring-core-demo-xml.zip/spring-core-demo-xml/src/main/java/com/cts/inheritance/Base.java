package com.cts.inheritance;

public class Base {
	private String parent;
	
	@Override
	public String toString() {
		return "Base [parent=" + parent + "]";
	}

	public Base() {
	}

	public String getParent() {
		return parent;
	}

	public void setParent(String parent) {
		this.parent = parent;
	}
	
	

}
