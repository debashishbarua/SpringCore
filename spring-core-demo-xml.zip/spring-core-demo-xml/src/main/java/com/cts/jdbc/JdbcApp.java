package com.cts.jdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.jdbc.model.Student;
import com.cts.jdbc.service.StudentService;

public class JdbcApp {
	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("jdbcConfig.xml");

		StudentService service = ctx.getBean(StudentService.class);

		Student student = new Student(13, "Akash");

		service.save(student);
		System.out.println(service.findAll());
	}
}
