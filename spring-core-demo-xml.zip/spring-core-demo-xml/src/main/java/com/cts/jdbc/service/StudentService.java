package com.cts.jdbc.service;

import java.util.List;

import com.cts.jdbc.model.Student;
import com.cts.jdbc.repository.StudentRepository;

public class StudentService {

	private StudentRepository studentRepository;	

	public StudentService() {

	}	

	public void setStudentRepository(StudentRepository studentRepository) {
		this.studentRepository = studentRepository;
	}

	public List<Student> findAll() {
		return studentRepository.findAll();
	}

	public void save(Student student) {
		studentRepository.save(student);

	}
}
