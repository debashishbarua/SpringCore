package com.cts.jdbc.repository;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.cts.jdbc.model.Student;

public class StudentRepository {

	private JdbcTemplate jdbcTemplate;

	public StudentRepository() {

	}

	public void setJdbcTemplate(DataSource dataSource) {

		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public List<Student> findAll() {
		String sql = "select * from Student";
		return jdbcTemplate.query(sql, new StudentMapper());
	}

	public void save(Student student) {
		String sql = "insert into student values(?,?)";
		jdbcTemplate.update(sql, student.getId(), student.getName());

	}

}
