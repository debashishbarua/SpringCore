package com.cts.autowiring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AutowiredApp {

	public static void main(String[] args) {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("personAutowiring.xml");
		Person person = ctx.getBean(Person.class, "person");
		System.out.println(person);
		Department d=ctx.getBean(Department.class);
		System.out.println(d);
		
		Employee e=ctx.getBean(Employee.class);
		System.out.println(e);
	}

}
