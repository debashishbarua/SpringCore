package com.cts.autowiring;

public class Employee {
	private String name;
	private Department department;

	public Employee() {
	}

	public Employee(String name, Department department) {
		super();
		this.name = name;
		this.department = department;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", department=" + department + "]";
	}

}
