package com.cts.collections;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ListTestApp {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("listConfig.xml");
		NameManager nameManager = (NameManager) ctx.getBean("nameManager");
		System.out.println(nameManager.getNames());
		System.out.println(nameManager.getCities());
		System.out.println(nameManager.getAddressMap());
		System.out.println(nameManager.getAddressProp());

	}

}
