package com.cts.collections;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class NameManager {
	
	private List<String> names;
	private Set<String> cities;
	private Map  addressMap;
	private   Properties addressProp;
	public List<String> getNames() {
		return names;
	}

	public void setNames(List<String> names) {
		this.names = names;
	}

	public Set<String> getCities() {
		return cities;
	}

	public void setCities(Set<String> cities) {
		this.cities = cities;
	}

	public Map getAddressMap() {
		return addressMap;
	}

	public void setAddressMap(Map addressMap) {
		this.addressMap = addressMap;
	}

	public Properties getAddressProp() {
		return addressProp;
	}

	public void setAddressProp(Properties addressProp) {
		this.addressProp = addressProp;
	}


}
