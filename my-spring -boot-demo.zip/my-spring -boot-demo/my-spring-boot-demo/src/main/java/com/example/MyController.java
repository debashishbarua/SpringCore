package com.example;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.model.User;

@Controller
public class MyController {
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	//@GetMapping("/loginPage")
	public String getLoginPage() {
		return "login"; // login.jsp
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	//@GetMapping("/loginPage")
	public String doLogin(
			@RequestParam("userName") String userName,
			@RequestParam("password") String password) {
		
		User user=new User(userName, password);
		if(user.getUserName().equals("Admin") && 
				user.getPassword().equals("Admin"))
				return "success"; 
		else {
			return "fail";
		}
	}
	

}
